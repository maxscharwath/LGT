var chaine = "lesgrossestanches";
var title = "Les Grosses Tanches";
var message = "Les Grosses Tanches sont en live sur @game.";
var redirectUrl = "https://www.twitch.tv/lesgrossestanches";
